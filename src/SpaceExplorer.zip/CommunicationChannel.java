import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Semaphore;

/**
 * Class that implements the channel used by headquarters and space explorers to
 * communicate.
 */
public class CommunicationChannel {
	private static final int sizeSPtoHQ = 10000;
	private static final int sizeHQtoSP = 10000;
	
	private ArrayBlockingQueue<Message> fromSpaceExpToHQ;
	private ArrayBlockingQueue<Message> fromHQToSpaceExp;

	/**
	 * Creates a {@code CommunicationChannel} object.
	 */
	public CommunicationChannel() {
		fromSpaceExpToHQ = new ArrayBlockingQueue<>(sizeSPtoHQ, true);
		fromHQToSpaceExp = new ArrayBlockingQueue<>(sizeHQtoSP, true);
	}

	/**
	 * Puts a message on the space explorer channel (i.e., where space explorers
	 * write to and headquarters read from).
	 * 
	 * @param message message to be put on the channel
	 */
	public void putMessageSpaceExplorerChannel(Message message) {
		// put in fromSpaceExptoHQ
		try {
			
			fromSpaceExpToHQ.put(message);
			
		} catch (InterruptedException e) {
			
		}
	}

	/**
	 * Gets a message from the space explorer channel (i.e., where space explorers
	 * write to and headquarters read from).
	 * 
	 * @return message from the space explorer channel
	 */
	public Message getMessageSpaceExplorerChannel() {
		Message value = null;

		try {
			value = fromSpaceExpToHQ.take();
		
		} catch (InterruptedException e) {
			
		}

		return value;
	}

	/**
	 * Puts a message on the headquarters channel (i.e., where headquarters write to
	 * and space explorers read from).
	 * 
	 * @param message message to be put on the channel
	 */
	public void putMessageHeadQuarterChannel(Message message) {
		try {
			fromHQToSpaceExp.put(message);
			
		} catch (InterruptedException e) {
			
		}
	}

	/**
	 * Gets a message from the headquarters channel (i.e., where headquarters write
	 * to and space explorer read from).
	 * 
	 * @return message from the header quarter channel
	 */
	public Message getMessageHeadQuarterChannel() {
		Message value = null;

		try {
			value = fromHQToSpaceExp.take();
		} catch (InterruptedException e) {
			
		}

		return value;
	}
}
